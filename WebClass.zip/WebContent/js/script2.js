     function menu_over(e){
        e.setAttribute("class","nav-item active");      // li class="nav-item active"
     }
     function menu_out(e){
        e.setAttribute("class","nav-item");            // li calss="nav-item"
     }